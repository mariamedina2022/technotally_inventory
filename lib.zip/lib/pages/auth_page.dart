import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:technotally_inventory/pages/login_or%20register.dart';
import 'package:technotally_inventory/pages/home_page.dart';

class AuthPage extends StatelessWidget{
  const AuthPage({super.key});

  @override
  Widget build(BuildContext context){
    return Scaffold(
      body: StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot){
          // if user login
          if(snapshot.hasData) {
            return HomePage();
          }

          //user not login
          else{ return const LoginOrRegisterPage();}
        }
      ),
    );
  }
}