import 'package:flutter/material.dart';
import 'package:technotally_inventory/pages/login_page.dart';
import 'package:technotally_inventory/pages/register.dart';

class LoginOrRegisterPage extends StatefulWidget{
  const LoginOrRegisterPage({super.key});

  @override
  State<LoginOrRegisterPage> createState() => _LoginOrRegisterPageState();
}

class _LoginOrRegisterPageState extends State<LoginOrRegisterPage>{

  //initially show login page
  bool showLoginPage = true;

//method to toogle between login and register path
  void tooglePages(){
    setState(() {
      showLoginPage=!showLoginPage;
    });
  }

  @override
  Widget build(BuildContext context){
    if (showLoginPage){
    return LoginPage(onTap: tooglePages,
      );
    } else {
      return RegisterPage(
        onTap: tooglePages,);
    }
  }

  // //method to toogle between login and register path
  // void tooglePages() {
  //   setState(() {
  //     showLoginPage = !showLoginPage;
  //      });
  
}
