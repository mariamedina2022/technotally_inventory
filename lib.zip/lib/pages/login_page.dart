import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:technotally_inventory/components/my_textfield.dart';
import 'package:technotally_inventory/components/my_button.dart';
import 'package:technotally_inventory/components/square_tile.dart';
import 'package:technotally_inventory/pages/register.dart';


class LoginPage extends StatefulWidget {
  final Function()? onTap;
  const LoginPage({super.key, required this.onTap});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {

  // text editing controller
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  void signUserIn() async{
    //show loading circle
    showDialog(context: context,
    builder: (context){
      return const Center(
        child: CircularProgressIndicator(),
      );
    },);

    //try sign in
    try{
       await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: emailController.text, 
        password: passwordController.text,
        );
         //hilangkan circle login
        Navigator.pop(context);

    } on FirebaseAuthException catch (e){

     //hilangkan circle login
        Navigator.pop(context);
      
      //show error message if login fail
      showErrorMessage(e.code);

    }
        
  }

  //Error message if wrong log in
 void showErrorMessage(String message){
  showDialog(
    context: context, 
    builder: (context){
      return AlertDialog(
        backgroundColor: Colors.black,
        title: Center(
          child: Text(
            message,
            style: const TextStyle(color : Colors.white),
          ),
        ),
      );
    },
    );
 }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[300],
      body: SafeArea(
        child: Center(
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
            
                  SizedBox(height: 30),
                  Image(
                    image: AssetImage('lib/images/logo.png'),
                    width: 100,
                    height: 100,
                  ),
            
                  SizedBox(height: 40),
            
                  Text(
                    'Welcome to TechnoTally!',
                    style: TextStyle(
                      color: Color.fromARGB(255, 51, 50, 50),
                      fontSize: 16,
                    ),
                  ),
            
                  SizedBox(height: 30),
            
                  MyTextField(
                    controller: emailController,
                    hintText: 'Username',
                    obscureText: false,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Username is required';
                      }
                      return null;
                    },
                  ),
            
                  SizedBox(height: 10),
            
                  MyTextField(
                    controller: passwordController,
                    hintText: 'Password',
                    obscureText: true,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Password is required';
                      }
                      return null;
                    },
                  ),
            
                  SizedBox(height: 10),
            
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 25.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          'Forgot Password?',
                          style: TextStyle(color: Colors.grey[600]),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 30),
            
                  MyButton(
                    text: "Sign In",
                    onTap: signUserIn,
                  ),
            
                  SizedBox(height: 50),
            
            
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 25.0),
                    child: Row(
                      children: [
                        Expanded(
                          child: Divider(
                            thickness: 0.5,
                            color: Colors.grey[400],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 10.0),
                          child: Text(
                            'or continue with',
                            style: TextStyle(color: Colors.grey[700]),
                          ),
                        ),
                        Expanded(
                          child: Divider(
                            thickness: 0.5,
                            color: Colors.grey[400],
                          ),
                        ),
                      ],
                    ),
                  ),
            
                  SizedBox(height: 30),
            
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SquareTile(
                        imagePath: 'lib/images/google.png',
                      ),
                    ],
                  ),
                  SizedBox(height: 30),

                  //register
            
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Not a member?',
                        style: TextStyle(color: Colors.grey[700]),
                      ),
                      const SizedBox(width: 4),
                      GestureDetector(
                         onTap: widget.onTap,
                        child: const Text(
                          'Register now',
                          style: TextStyle(
                            color: Colors.blue, 
                            fontWeight: FontWeight.bold
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
    );
  }
}
