import 'package:flutter/material.dart';

class NamedTextFormField extends FormField<String> {
  final String name; // Add a name attribute

  NamedTextFormField({
    Key? key,
    required this.name,
    required TextEditingController controller,
    InputDecoration decoration = const InputDecoration(),
    FormFieldSetter<String>? onSaved,
    FormFieldValidator<String>? validator, required String labelText, required bool obscureText,
  }) : super(
          key: key,
          onSaved: onSaved,
          validator: validator,
          builder: (state) {
            return TextFormField(
              controller: controller,
              decoration: decoration,
              onChanged: state.didChange,
            );
          },
        );

  @override
  FormFieldState<String> createState() {
    return super.createState();
  }
}
